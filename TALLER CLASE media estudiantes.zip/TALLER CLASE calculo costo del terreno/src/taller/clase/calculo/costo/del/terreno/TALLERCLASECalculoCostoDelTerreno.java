
package taller.clase.calculo.costo.del.terreno;

import java.util.Scanner;

public class TALLERCLASECalculoCostoDelTerreno {

    public static void main(String[] args) {
        Scanner costos = new Scanner (System.in);
        
        //declaracion de variables
        double anchura, altura, costoMetro, costoto, area;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA ANCHURO DEL TERRENO: ");
        anchura = costos.nextDouble();
        System.out.print("INGRESE LA ALTURA DEL TERRENO: ");
        altura = costos.nextDouble();
        System.out.print("INGRESE EL COSTO EL COSTO POR METRO: ");
        costoMetro = costos.nextDouble();
        
        //calculo del area del terreno
        area = anchura * altura;
        
        //calculo del costo del terreno
        costoto = area * costoMetro;
        
        //salida del resultado al usuario
        System.out.println("EL COSTO TOTAL DEL TERRENO ES DE: "+costoto);
        
    }
    
}
