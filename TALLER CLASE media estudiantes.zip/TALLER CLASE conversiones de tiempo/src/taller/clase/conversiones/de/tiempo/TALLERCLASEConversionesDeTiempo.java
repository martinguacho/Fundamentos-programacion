
package taller.clase.conversiones.de.tiempo;

import java.util.Scanner;

public class TALLERCLASEConversionesDeTiempo {
    
    public static void main(String[] args) {
        Scanner conversion = new Scanner (System.in);
        
        //declaracion de variables
        double horas, segundos, minutos, dias;
        int dia, minuto, segundo;
        
        //valores de variables
        dia = 24;
        minuto = 60;
        segundo = 60;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA CANTIDAD DE  HORAS QUE DESEA CONVERTIR: ");
        horas = conversion.nextInt();
        
        //calculo de la conversion a minutos
        minutos = horas * minuto;
        
        //calculo de la conversion a segundos
        segundos = horas * minuto * segundo;
        
        //calculo de la conversion a dias
        dias = horas / dia;
        
        //muestra del resultado al usuario
        System.out.println("LAS " +horas+ " HORAS QUE INGRESO SON EQUIVALENTES A: ");
        System.out.println(minutos+" MINUTOS");
        System.out.println(segundos+" SEGUNDOS");
        System.out.println(dias+" DIAS");
        
    }
    
}
