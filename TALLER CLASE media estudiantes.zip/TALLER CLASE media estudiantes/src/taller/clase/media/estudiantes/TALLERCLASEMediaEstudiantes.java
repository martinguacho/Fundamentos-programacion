
package taller.clase.media.estudiantes;

import java.util.Scanner;

public class TALLERCLASEMediaEstudiantes {
    
    public static void main(String[] args) {
        Scanner media = new Scanner (System.in);
        
        // declaracion de variables
        double estat1, estat2, estat3, estat4, estat5, sumatoria, promedio;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA ESTATURA DEL PRIMER ALUMONO: ");
        estat1 = media.nextDouble();
        System.out.print("INGRESE LA ESTATURA DEL SEGUNDO ALUMONO: ");
        estat2 = media.nextDouble();
        System.out.print("INGRESE LA ESTATURA DEL TERCER ALUMONO: ");
        estat3 = media.nextDouble();
        System.out.print("INGRESE LA ESTATURA DEL CUARTO ALUMONO: ");
        estat4 = media.nextDouble();
        System.out.print("INGRESE LA ESTATURA DEL QUINTO ALUMONO: ");
        estat5 = media.nextDouble();
        
        //calculo de la suma de estaturas
        sumatoria = estat1 + estat2 + estat3 + estat4 + estat5;
        
        //calculo de la media del curso
        promedio = sumatoria / 5;
        
        //salida de la respuesta al usuario
        System.out.println("LA MEDIA TOTAL DEL CURSO ES: "+promedio);
    }
    
}
