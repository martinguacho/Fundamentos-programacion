
package deber.ejercicio17;

import java.util.Scanner;

public class DEBEREjercicio17 {

    public static void main(String[] args) {
        Scanner angulo = new Scanner (System.in);
        
        //declaracion de variables
        double tamaño, tangente, cotangente, secante, cosecante, seno, coseno, hipotenusa, opuesto, adyacente;
        
        //peticion de datos al usuario
        System.out.print("INGRESE EL TAMAÑO DEL ÁNGULO EN RADIANES: ");
        tamaño = angulo.nextDouble();
        System.out.print("INGRESE EL LADO MAS GRANDE (HIPOTENUSA): ");
        hipotenusa = angulo.nextDouble();
        System.out.print("INGRESE EL LADO OPUESTO: ");
        opuesto = angulo.nextDouble();
        System.out.print("INGRESE EL LADO ADYACENTE: ");
        adyacente = angulo.nextDouble();
        
        //calculo del seno
        seno = opuesto / hipotenusa;
        
        //calculo del coseno
        coseno = adyacente / hipotenusa;
        
        //calculo de la tangente
        tangente = seno / coseno;
        
        //calculo de la cotangente
        cotangente = coseno / seno;
        
        //calculo de la secante 
        secante = 1 / coseno;
        
        //calculo de la cosecante
        cosecante = 1 / seno;
        
        //salida de datos al usuario
        System.out.println("LA TANGENTE DEL ANGULO " +tamaño+" ES DE: "+tangente+" RADIANES");
        System.out.println("LA COTANGENTE DEL ANGULO " +tamaño+" ES DE: "+cotangente+" RADIANES");
        System.out.println("LA SECANTE DEL ANGULO " +tamaño+" ES DE: "+secante+" RADIANES");
        System.out.println("LA COSECANTE DEL ANGULO " +tamaño+" ES DE: "+cosecante+" RADIANES");
        
        
                
                
                //
    }
    
}
