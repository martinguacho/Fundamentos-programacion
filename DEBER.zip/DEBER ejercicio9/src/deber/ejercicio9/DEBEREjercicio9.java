
package deber.ejercicio9;

import java.util.Scanner;


public class DEBEREjercicio9 {

    public static void main(String[] args) {
        Scanner articulo = new Scanner (System.in);
        
        //declaracion de variables
        String objeto;
        double costo, utilidad, impuesto, venta, costoto, utilidadto, impuestoto;
        
        //valores de variables
        utilidad = 1.5;
        impuesto = 0.15;
        
        //peticion de datos al usuario
        System.out.print("INGRESE EL ARTICULO QUE DESEA VENDER: ");
        objeto = articulo.next();
        System.out.print("INGRESE EL COSTO DEL ARTICULO: ");
        costo = articulo.nextDouble();
        
        //calculo de la utilidad
        utilidadto = costo * utilidad;
        
        //calculo del impuesto
        impuestoto = costo * impuesto;
        
        //calculo del costo de venta del articulo
        venta = costo + utilidadto + impuestoto;
        
        //salida de datos al usuario
        System.out.println("LA UTILIDAD DE: "+objeto+" ES DE: "+utilidadto);
        System.out.println("EL IMPUESTO DE: "+objeto+" ES DE: "+impuestoto);
        System.out.println("EL PRECIO TOTAL DE VENTA DE "+objeto+" ES DE: "+venta);
        
    }
    
}
