
package deber.ejercicio1;

import java.util.Scanner;

public class DEBEREjercicio1 {

    public static void main(String[] args) {
        Scanner produccion = new Scanner (System.in);
        
        //declaracion de variables
        String articulo;
        double subtotal, costoto, costoMa;
        int costoFi, unidades;
        
        //valores de variables
        costoMa = 3.5;
        costoFi = 10700;
        
        //peticion de datos al usuario
        System.out.print("INGRESE QUE ARTICULO DESEA PRODUCIR: ");
        articulo = produccion.next();
        System.out.print("INGRESE LA CANTIDAD DE "+articulo+" QUE DESEA PRODUCIR: ");
        unidades = produccion.nextInt();
        
        //calculo del subtotal
        subtotal = unidades * costoMa;
        
        //calculo del valor total de la produccion
        costoto = subtotal + costoFi;
        
        //salida del resultado al usuario
        System.out.println("EL COSTO TOTAL DE LAS "+ unidades + articulo +" ES DE: "+costoto+"dolares");
    }
    
}
