
package deber.ejercicio19;

import java.util.Scanner;

public class DEBEREjercicio19 {

    public static void main(String[] args) {
        Scanner angulo = new Scanner (System.in);
        
        //declaracion de variables
        double tamaño, seno, coseno, opuesto, adyacente, hipotenusa, radianes, pi;
        
        //valor de variables
        pi = 3.1416;
        
        //peticion de datos al usuario
        System.out.print("INGRESE EL TAMAÑO DEL ANGULO EN GRADOS: ");
        tamaño = angulo.nextDouble();
        System.out.print("INGRESE EL LADO MAS GRANDE (HIPOTENUSA): ");
        hipotenusa = angulo.nextDouble();
        System.out.print("INGRESE EL LADO OPUESTO: ");
        opuesto = angulo.nextDouble();
        System.out.print("INGRESE EL LADO ADYACENTE: ");
        adyacente = angulo.nextDouble();
        
        //calculo de los grados a radianes
        radianes = tamaño * (pi / 180);
        
        //calculo del seno
        seno = opuesto / hipotenusa;
        
        //calculo del coseno
        coseno = adyacente / hipotenusa;
        
        //salida de datos al usuario
        System.out.println("EL ANGULO " +tamaño+" EN RADIANES ES DE: "+radianes+" RADIANES");
        System.out.println("EL SENO DEL ANGULO " +tamaño+" ES DE: "+seno+" RADIANES");
        System.out.println("EL COSENO " +tamaño+" ES DE: "+coseno+" RADIANES");
        
    }
    
}
