
package deber.ejercicio3;

import java.util.Scanner;

public class DEBEREjercicio3 {

    public static void main(String[] args) {
        Scanner conversion = new Scanner (System.in);
        
        //declaracion de variables
        double horas, minutos, dias, segundos;
        int minuto, dia, hora;
        
        //valor de las variables
        hora = 60;
        minuto = 60;
        dia = 24;
        //peticion de datos al usuario
        System.out.print("INGRESE LAS HORAS QUE DESEA CONVERTIR: ");
        horas = conversion.nextDouble();
        
        //conversion a minutos
        minutos = horas * minuto;
        
        //conversion a segundos
        segundos = horas * hora * minuto;
        
        //conversion a dias
        dias = horas / dia;
        
        //salida de los resultados al usuario
        System.out.println("LAS "+horas+" HORAS INGRESADAS EQUIVALEN A: ");
        System.out.println("EN MINUTOS: "+minutos+" MINUTOS");
        System.out.println("EN SEGUNDOS: "+segundos+" SEGUNDOS");
        System.out.println("EN DIAS: "+dias+" DIAS");
    }
    
}
