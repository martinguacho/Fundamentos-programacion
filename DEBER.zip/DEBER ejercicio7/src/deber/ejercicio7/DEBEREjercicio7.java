
package deber.ejercicio7;

import java.util.Scanner;

public class DEBEREjercicio7 {

    public static void main(String[] args) {
        Scanner grados = new Scanner (System.in);
        
        //declaracion de variables
        double gradosC, gradosF, fraccion;
        
        //valor de variables
        fraccion = 1.8;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA TEMPERATURA EN GRADOS CELSIUS QUE DESEA CONVERTIR A FAHRENHEIT: ");
        gradosC = grados.nextDouble();
        
        //calculo de la conversion
        gradosF = fraccion * gradosC + 32;
        
        //salida de datos al usuario
        System.out.println("LA CANTIDAD DE "+gradosC+" GRADOS CELSIUS A FAHRENHEIT ES DE: "+gradosF+" GRADOS FAHRENHEIT");
    }
    
}
