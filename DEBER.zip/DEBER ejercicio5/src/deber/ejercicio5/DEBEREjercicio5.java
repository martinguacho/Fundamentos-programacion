
package deber.ejercicio5;

import java.util.Scanner;

public class DEBEREjercicio5 {

    public static void main(String[] args) {
        Scanner luz = new  Scanner (System.in);
        
        //declaracion de variables
        int velocidad;
        double segundos, distancia;
        
        //valor de las variables
        velocidad = 300000;
        
        //peticion de datos al usuario
        System.out.print("INGRESE EL TIEMPO EN SEGUNDOS QUE DEASEA CONOCER: ");
        segundos = luz.nextDouble();
        
        //calculo de la distancia a la velocidad de la luz
        distancia = velocidad * segundos;
        
        //salida de datos al usuario
        System.out.println("EN "+segundos+" SEGUNDOS, LA DISTANCIA QUE RECORRERA SERA DE: "+distancia+" KM.");
        
    }
    
}
