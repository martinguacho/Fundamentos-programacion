
package deber.ejercicio11;

import java.util.Scanner;

public class DEBEREjercicio11 {

    public static void main(String[] args) {
        Scanner cambio = new Scanner (System.in);
        
        //declaracion de variables
        double dolares, dolar, pesos;
        
        //valores de variables
        dolar = 2840.9;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA CANTIDAD DE DOLARES QUE DESEA COMPRAR: ");
        dolares = cambio.nextDouble();
        
        //calculo del costo de los dolares en pesos
        pesos = dolar * dolares;
        
        //salida de datos al usuario
        System.out.println("LOS "+dolares+" DOLARES EN PESOS LE COSTARAN: "+pesos+" PESOS.");
        
    }
    
}
