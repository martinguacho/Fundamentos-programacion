
package deber.ejercicio15;

import java.util.Scanner;

public class DEBEREjercicio15 {

    public static void main(String[] args) {
        Scanner cambio = new Scanner (System.in);
        
        //declaracion de variables
        double dolares, yenes, pesetas, libras, marcos, yene, peseta, libra, marco;
        
        //valor de las variables
        yene = 109.03;
        peseta = 156.66;
        libra = 0.8;
        marco = 5.6;
        
        //peticion de datos al usuario
        System.out.print("INGRESE LA CANTIDAD DE DOLARES QUE DESEA COMPRAR: ");
        dolares = cambio.nextDouble();
        
        //calculo de cambio a yenes
        yenes = dolares * yene;
        
        //calculo de cambio a pesetas
        pesetas = dolares * peseta;
        
        //calculo de cambio a libras esterlinas
        libras = dolares * libra;
        
        //calculo de cambio a marcos
        marcos = dolares * marco;
        
        //salida de datos al usuario
        System.out.println("LA CANTIDAD DE "+dolares+" EN YENES ES DE: "+yenes+" YENES");
        System.out.println("LA CANTIDAD DE "+dolares+" EN PESETAS ES DE: "+pesetas+" PESETAS");
        System.out.println("LA CANTIDAD DE "+dolares+" EN LIBRAS ESTERLINAS ES DE: "+libras+" LIBRAS ESTERLINAS");
        System.out.println("LA CANTIDAD DE "+dolares+" EN MARCOS ES DE: "+marcos+" MARCOS");
    }
    
}
