
package deber.ejercicio13;

import java.util.Scanner;

public class DEBEREjercicio13 {

    public static void main(String[] args) {
        Scanner esfera = new Scanner (System.in);
        
        //declaracion de variables
        double radio, volumen, area, pi;
        
        //valores de variables
        pi = 3.1416;
        
        //peticion de datos al usuario
        System.out.print("INGRESE EL RADIO DE LA ESFERA: ");
        radio = esfera.nextDouble();
        
        //calculo del volumen
        volumen = (4 * pi) *( radio * radio * radio) / 3;
        
        //calculo del area
        area = pi * (radio * radio);
        
        //salida de resultados al usuario
        System.out.println("EL VOLUMEN DE LA ESFERA ES DE: "+volumen);
        System.out.println("EL AREA DE LA ESFERA ES DE: "+area);
        
    }
    
}
